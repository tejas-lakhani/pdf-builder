# pdf-sign

Finally, a simple way to put your signature on a PDF for free.

### Live site: [https://slavik0329.github.io/pdf-sign/](https://slavik0329.github.io/pdf-sign/)
